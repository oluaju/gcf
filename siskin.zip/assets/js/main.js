var body = $('body');

document.addEventListener('lazyloaded', function (e) {
    'use strict';
});

$(function () {
    'use strict';
    player();
    mobileMenu();
    mobileSubmenu();

});
$(window).resize(function() {
    mobileSubmenu();
});

function mobileMenu(){
    $('.siskin-burger').click(function () {
        $('body').toggleClass('siskin-head-open');
    });
}

function mobileSubmenu(){
    if ($(window).width() < 930) {
        $('.siskin-nav-trigger').click(function () {
            $(this).parent().toggleClass('siskin-nav-open');
        });        
    }
}


function player() {
    'use strict';
    var player = $('.player');
    var playerAudio = $('.player-audio');
    var playerMedia = player.find('.post-media');
    var playerThumbnail = player.find('.post-image');
    var playerTitle = player.find('.post-title-link');   
    
    var playerProgress = $('.player-progress');
    var playerSpeed = 1;
    var buttonEpisode;
    var buttonPlay = $('.player-button-play');
    var buttonBackward = $('.player-button-backward');
    var buttonForward = $('.player-button-forward');
    var buttonSpeed = $('.player-button-speed');
    var buttonClose = $('.player-button-close');
    var timeCurrent = $('.player-time-current');
    var timeDuration = $('.player-time-duration');
    var buttonDownload = $('.btn-download');
    var buttonTweet = $('.btn-tw');
    var buttonFb = $('.btn-fb');

    $('.viewport').on('click', '.js-play', function () {
        var clicked = $(this);
        var url = clicked.attr('data-url');
        var id = clicked.attr('data-id');


        if ($('.player-external').length) {
            body.addClass('player-opened');
        }


        if (id !== playerMedia.attr('data-id')) {
            // Change audio player url
            playerAudio.attr('src', url);

            // Change player thumbnail
           // playerThumbnail.attr('srcset','data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==');
            playerThumbnail.attr(
                'srcset',
                clicked.find('.post-image').attr('src')
            );

            // Change player title
            
            playerTitle.text(
                clicked.closest('.post').find('.post-card-title').text()
            );
           

            // Change button download link 
            buttonDownload.attr('href', url);

            // Change button Facebook link 
            buttonFb.attr('href', 'https://www.facebook.com/sharer.php?u='+site_url+clicked.closest('.post').find('.post-card-title a').attr('href'));

            // Change button twitter link 
            buttonTweet.attr('href', 'https://twitter.com/intent/tweet?url='+site_url+clicked.closest('.post').find('.post-card-title a').attr('href'));

            // Make previous episode button pause
            $('.post-' + playerMedia.attr('data-id'))
                .find('.icon')
                .removeClass('icon-pause').addClass('icon-play');

            // Change player media id attribute
            playerMedia.attr('data-id', id);
            buttonPlay.attr('data-id', id);

            // Select current episode button
            buttonEpisode = $('[data-id="' + id + '"]').find('.icon-play');
        }

        if (playerAudio[0].paused) {
            var playPromise = playerAudio[0].play();
            if (playPromise !== undefined) {
                playPromise
                    .then(function () {
                        // Make clicked button pause
                        clicked.find('.icon').removeClass('icon-play').addClass('icon-pause');
                        // Make playing episode button pause
                        if (buttonEpisode) {
                            buttonEpisode.addClass('icon-pause');
                        }
                    })
                    .catch(function (error) {
                        console.log(error);
                    });
            }
        } else {
            playerAudio[0].pause();
            // Make clicked button play
            clicked.find('.icon').removeClass('icon-pause').addClass('icon-play');
            // Make paused episode button play
            if (buttonEpisode) {
                buttonEpisode.removeClass('icon-pause').addClass('icon-play');
            }
        }
    });

    playerAudio.on('loadedmetadata', function () {
       
        timeDuration.text(
            new Date(playerAudio[0].duration * 1000).toISOString().substr(11, 8)
        );
        playerAudio[0].addEventListener('timeupdate', function (e) {
            timeCurrent.text(
                new Date(e.target.currentTime * 1000)
                    .toISOString()
                    .substr(11, 8)
            );
            playerProgress.css(
                'width',
                (e.target.currentTime / playerAudio[0].duration) * 100 + '%'
            );
        });
    });

    buttonBackward.on('click', function () {
        playerAudio[0].currentTime = playerAudio[0].currentTime - 10;
    });

    buttonForward.on('click', function () {
        playerAudio[0].currentTime = playerAudio[0].currentTime + 30;
    });

    buttonSpeed.on('click', function () {
        if (playerSpeed < 2) {
            playerSpeed += 0.5;
        } else {
            playerSpeed = 1;
        }

        playerAudio[0].playbackRate = playerSpeed;
        buttonSpeed.text(playerSpeed + 'x');
    });
}