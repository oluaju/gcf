### Theme Info
```
Theme name: Siskin
Theme Developer: Iris Themes
Version: 1.5
Description: Podcast Ghost Theme
Documentation: https://iristhemes.com/documentation/siskin
Demo URL: http://siskin.iristhemes.com/
Support URL: https://iristhemes.com/contact/
Routes file: https://siskin.iristhemes.com/content/files/2022/06/routes.yaml
```
### Requirements
```
Ghost version: 4.0.0 or higher
Ghost Content API: v4
```

### How do I install Siskin Ghost theme?

- Make sure that you are logged into your publication at yourawesomeblog.com/ghost/signin
- Go to Settings → Design
- Under **Change Theme** click Upload theme
- Click inside the upload box to select a siskin.zip, or drag-and-drop the siskin.zip into the upload box
- If you want to activate the theme immediately click **Activate Now** or **Close** if you want to do it later


# First time using a Ghost theme?

Ghost uses a simple templating language called [Handlebars](https://handlebarsjs.com/) for its themes.

We've documented our default theme pretty heavily so that it should be fairly easy to work out what's going on just by reading the code and the comments. Once you feel comfortable with how everything works, we also have full [theme API documentation](https://themes.ghost.org) which explains every possible Handlebars helper and template.

**The main files are:**

- `default.hbs` - The main template file
- `index.hbs` - Used for the home page if you don't have routes filed added
- `post.hbs` - Used for individual posts
- `page.hbs` - Used for individual pages
- `tag.hbs` - Used for tag archives
- `custom-home.hbs` - Used for home page
- `custom-podcast.hbs` - Used for podcast page
- `custom-blog.hbs` - Used for blog listing page

# Changelog
**7.8.2023 - Siskin 1.6**

- Added: Post access meta labels
- Added: Featured area options - you can now pick between Featured in images, Newsletter form, Podcast networks and None
- Added: Recommendations - New ghost feature
- Added: YouTube icon
- Fixed: manifest.json path was causing the problem - this is now fixed
- Fixed: Several minor styling issues

**7.8.2023 - Siskin 1.5**

- Added: PWA (Progressive Web App) - your website now can be browsed offline and used as an app with just few tweaks
- Added: Deploy with GitHub
- Improved: Support for new Ghost page editor ( @page.show_title_and_feature_image)
- Fixed: Several minor styling issues

```
Added: .github/workflows/deploy-theme.yml
Modified: README.md
Added: assets/icon-192x192.png
Added: assets/icon-512x512.png
Modified: default.hbs
Added: manifest.json
Modified: package.json
Added: sw.js
Modified: page.hbs
```

**8.6.2023 - Siskin 1.4**

- Improved: Post selection for homepage - you can now use internal tags [#post-area-1 & #post-area-2] to add posts to 2 sections on homepage
- Improved: Benefits box editing - you can now edit Benefits section from [Settings / Design / Homepage / Benefits content]
- Improved: CTA box [newsletter box] editing - you can now edit Benefits section from [Settings / Design / Homepage / CTA Title & CTA Text]
- Fixed: Several minor styling issues

```
README.md
assets/built/screen.css
assets/built/screen.css.map
assets/css/screen.css
package.json
partials/section-about.hbs
partials/section-benefits.hbs
partials/section-blog.hbs
partials/section-newsletter.hbs
partials/section-podcast.hbs
```

**1.6.2023 - Siskin 1.3**

- Added: Set of theme options for front page most important sections
- Added: All posts (archive) page template
- Added: Membership page template
- Added: Related posts at the end of posts [Settings / Design / Post options]
- Fixed: Google Podcasts Icon problem
- Fixed: Several minor styling issues

```
Modified: assets/built/screen.css
Modified: assets/css/screen.css
Added: custom-archive.hbs
Added: custom-membership.hbs
Added: partials/related-posts.hbs
Modified: package.json
Modified: partials/section-about.hbs
Modified: partials/section-blog.hbs
Modified: partials/section-podcast.hbs
Modified: custom-post-with-table-of-contents-at-the-top.hbs
Modified: custom-post-with-table-of-contents.hbs
Modified: custom-post-with-title-up.hbs
Modified: default.hbs
Modified: post.hbs
```

**10.10.2022 - Siskin 1.2**

- Added: Progress bar at the top of posts
- Added: Reading time option in templates (reading-time=true in templates)
- Added: Ability to have dropdown menu in main navigation [Design / Homepage / Enable dropdown menu]
- Added: Table of contents page template with sidebar
- Added: Table of contents page template with ToC at the top of post / page
- Added: Pages widget (widget-pages.hbs)
- Added: Support for native Ghost Search functionoality (just add Search to the main menu and you are good to go :) )
- Improved: Form styling improvements so you can have contact form
- Fixed: Several minor styling issues

```

 README.md
 assets/built/global.css                            
 assets/built/global.css.map                        
 assets/built/main-min.js                           
 assets/built/main-min.js.map                       
 assets/built/main.js                                
 assets/built/main.js.map                           
 assets/built/screen.css                            
 assets/built/screen.css.map                        
 assets/css/global.css                              
 assets/css/screen.css                              
 assets/js/main.js                                  
 custom-blog.hbs                                    
 custom-post-with-sidebar.hbs                       
 ...h-table-of-contents-at-the-top-plus-sidebar.hbs 
 custom-post-with-table-of-contents-at-the-top.hbs  
 custom-post-with-table-of-contents.hbs             
 custom-post-with-title-up.hbs                      
 default.hbs                                        
 locales/en.json                                    
 package.json                                       
 partials/article-byline.hbs                        
 partials/blog-card.hbs                             
 partials/progress-bar.hbs                          
 partials/script-dropdown.hbs                       
 partials/section-blog.hbs                          
 partials/sidebar.hbs                               
 partials/widget-pages.hbs                          
 post.hbs                                           


```

**25.8.2022 - Siskin 1.1.1**

- Fixed: Issues with newsletter forms - sucess/error messages will now appear correctly
- Fixed: Several minor styling issues

```
Modified: assets/built/screen.css
Modified: assets/built/screen.css.map
Modified: assets/css/screen.css
Modified: custom-newsletter.hbs
Modified: locales/en.json
Modified: package.json
Modified: partials/section-newsletter.hbs
Modified: custom-post-with-sidebar.hbs

```

**18.8.2022**

- Added: Table of contents page template - you can now have posts with table of contents
- Added: Post with sidebar page template - you can now have post with sidebar
- Added: 3 custom widgets for new sidebar post template (list tags, ads widget and subscribe list widget)
- Added: Newsletter page template - you can now list your newsletters and create separate page for this as a landing page
- Added: Posts now support Ghost comments
- Fixed: Several minor styling issues

```
Modified: assets/css/screen.css
Added: custom-post-with-sidebar.hbs
Modified: partials/section-benefits.hbs
Added: partials/sidebar.hbs
Added: partials/widget-ads.hbs
Added: partials/widget-subscribe.hbs
Added: partials/widget-tags.hbs
Added: assets/built/main-min.js
Modified: assets/built/main.js
Added: custom-newsletter.hbs
Modified: default.hbs
Modified: gulpfile.js
Modified: package.json
Modified: post.hbs
```

**14.7.2022**

Initial release

# Copyright & License

Copyright (c) 2013-2021 Ghost Foundation - Released under the [MIT license](LICENSE).
